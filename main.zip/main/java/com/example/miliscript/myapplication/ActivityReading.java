package com.example.miliscript.myapplication;

import android.content.Intent;
import android.media.MediaPlayer;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class ActivityReading extends AppCompatActivity {

    private static Button nextBtn;
    private static Button playStory;
    private static Button playText;
    private static Button playComics;
    private static Button playPaper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_activity_reading);

        nextBtn = (Button) findViewById(R.id.back);

        // Capture button clicks
        nextBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent = new Intent(ActivityReading.this,HomeActivity.class);
                startActivity(myIntent);
            }
        });

        playStory = (Button) findViewById(R.id.storybook);
        playText = (Button) findViewById(R.id.textbook);
        playComics = (Button) findViewById(R.id.comics);
        playPaper = (Button) findViewById(R.id.paper);



        final MediaPlayer story= MediaPlayer.create(this, R.raw.simion);
        final MediaPlayer text= MediaPlayer.create(this, R.raw.text);
        final MediaPlayer comics= MediaPlayer.create(this, R.raw.comics);
        final MediaPlayer paper= MediaPlayer.create(this, R.raw.paper);

        playStory.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View view)
            {
                story.start();
            }
        });

        playText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View view)
            {
                text.start();
            }
        });

        playComics.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View view)
            {
                comics.start();
            }
        });

        playPaper.setOnClickListener(new View.OnClickListener() {
            @Override
            public void  onClick(View view)
            {
                paper.start();
            }
        });
    }
}
