package com.example.miliscript.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class HomeActivity extends AppCompatActivity {

    private static Button button_next;
    private static Button eatting_button;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        button_next = (Button) findViewById(R.id.reading);
        button_next.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent = new Intent(HomeActivity.this,ActivityReading.class);
                startActivity(myIntent);
            }
        });

        eatting_button = (Button) findViewById(R.id.eatting);
        eatting_button.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent = new Intent(HomeActivity.this,EattingActivity.class);
                startActivity(myIntent);
            }
        });
    }
}
