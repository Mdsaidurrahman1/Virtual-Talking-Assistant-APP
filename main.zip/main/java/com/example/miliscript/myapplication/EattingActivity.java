package com.example.miliscript.myapplication;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class EattingActivity extends AppCompatActivity {

    private static Button nextBtn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eatting);

        nextBtn = (Button) findViewById(R.id.back);

        // Capture button clicks
        nextBtn.setOnClickListener(new View.OnClickListener() {
            public void onClick(View arg0) {
                // Start NewActivity.class
                Intent myIntent = new Intent(EattingActivity.this,HomeActivity.class);
                startActivity(myIntent);
            }
        });
    }
}
